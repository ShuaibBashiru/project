from django.apps import AppConfig


class FormupdateConfig(AppConfig):
    name = 'formupdate'
