from django.apps import AppConfig


class FileGeneratorConfig(AppConfig):
    name = 'file_generator'
