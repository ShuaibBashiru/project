from django.urls import path
from . import views

urlpatterns = [
    # path('new_password_mailer/', newpassword_mailer.new_password_mailer, name="new_password_mailer"),
]