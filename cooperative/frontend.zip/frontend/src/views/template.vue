<template>
<div>
<div class="col-md-10 col-md-offset-2 maindiv">
<div class="container">
    <div class="row">
        <div class="col-12">
            <!-- Start of wrapper -->
<div class="row border p-2 m-0">
<div class="col-12">
    <h2>Healthcare Transaction Portal</h2>
    <div class="table-responsive">
<table id="user-table" class="table table-bordered nowrap" cellspacing="0" width="100%">
    <!-- {{sms}} -->
    <thead>
        <tr>
            <th>S/N</th>
            <th>Description</th>
            <th>Payment ID</th>
            <th>Price Set</th>
            <th>Actual Range</th>
            <th>Quantity</th>
            <th>Total</th>
            <th>Date Created</th>
            <th>Created By</th>
        </tr>
    </thead>
    <tbody>

        <tr>
            <td>1</td>
            <td>Film Hoper</td>
            <td>213213812318</td>
            <td>2600000</td>
            <td>200000 - 200000</td>
            <td>4</td>
            <td>10400000</td>
            <td>2021</td>
            <td>Admin</td>
        </tr>
        
        <tr>
            <td>2</td>
            <td>Dental x-ray</td>
            <td>213213812318</td>
            <td>210000</td>
            <td>3000000 - 3000000</td>
            <td>4</td>
            <td>840000</td>
            <td>2021</td>
            <td>Admin</td>
        </tr>
                
        <tr>
            <td>3</td>
            <td>Dental x-ray</td>
            <td>213213812318</td>
            <td>210000</td>
            <td>3000000 - 3000000</td>
            <td>4</td>
            <td>840000</td>
            <td>2021</td>
            <td>Admin</td>
        </tr>        
        <tr>
            <td>4</td>
            <td>Dental x-ray</td>
            <td>213213812318</td>
            <td>210000</td>
            <td>3000000 - 3000000</td>
            <td>4</td>
            <td>840000</td>
            <td>2021</td>
            <td>Admin</td>
        </tr>
        <tr>
            <td>5</td>
            <td>OPG UNIT</td>
            <td>213213812318</td>
            <td>2600000</td>
            <td>200000 - 200000</td>
            <td>4</td>
            <td>10400000</td>
            <td>2021</td>
            <td>Admin</td>
        </tr>
        <tr>
            <td>6</td>
            <td>Film Hoper</td>
            <td>213213812318</td>
            <td>2600000</td>
            <td>200000 - 200000</td>
            <td>4</td>
            <td>10400000</td>
            <td>2021</td>
            <td>Admin</td>
        </tr>
        
        <tr>
            <td>7</td>
            <td>Film Hoper</td>
            <td>213213812318</td>
            <td>2600000</td>
            <td>200000 - 200000</td>
            <td>4</td>
            <td>10400000</td>
            <td>2021</td>
            <td>Admin</td>
        </tr>

    </tbody>

</table>


    </div>
</div>
</div>

<!-- End of wrapper -->
    </div>
</div>

</div>
</div>
</div>
</template>
