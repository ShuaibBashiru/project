<template>
    <div>
        <div class="container">
            <div class="row mb-5">
                <div class="col-md-12 text-center mt-4"><h2>Hi, how can we help? </h2></div>
            </div>

            <div class="row">
                <div class="col-md-5 mt-4">
                    <h3>Help & Support</h3>
                    <p class="lead">Have questions or need to report an issue with our service or questions, suggestions? We've got you covered. </p>
                <a class="nav-link p-0" href="auth/signin"><button class="btn btn-primary">Write us a message</button></a>
                </div>
                <div class="col-md-2 mt-4"></div>
                <div class="col-md-5 mt-4">
                    <h3>Mail Us</h3>
                    <p class="lead"></p>
               <a class="nav-link p-0" href="mailto:support@thissite.com">Email: support@thissite.com</a>
               <a class="nav-link p-0" href="tel:+2348129010101">Phone: +2348129010101</a>
                </div>
            </div>


        <div class="row mt-5">
                <div class="col-md-5">
                    <h3> Address </h3>
                    <p class="lead">
                    1600 Amphitheatre Parkway
                    Mountain View, CA 94043, USA
                    (650) 253-0000</p>
                </div>
           
            </div>

        </div>
    </div>
</template>

<style>
.lead{
  color: #0a010196;
font-size: 18px;

}
</style>