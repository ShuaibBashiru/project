<template>
    <div>
        <div class="container">
    <div class="">
    <div class="row">
        <div class="col-md-12">
          <div class="p-1 pb-0 ml-0 pl-0">
               <h5><i class="bi-person-plus" style="font-size: 1.5rem;"></i> User's Account </h5>
          </div>
        </div>
          <div class="col-md-12 p-0">
 <div class="btn-toolbar m-1" role="toolbar" aria-label="Toolbar with button groups">
           <div class="btn-group m-2" role="group" aria-label="First group"><router-link to="/oath/user" class="btn btn-primary text-center">  <i class="bi-person-circle"></i> New </router-link></div>
           <div class="btn-group m-2" role="group" aria-label="First group"><router-link to="/" class="btn btn-info text-center">  <i class="bi-person-plus"></i> Profile </router-link></div>
           <div class="btn-group m-2" role="group" aria-label="First group"><router-link to="/" class="btn btn-primary text-center">  <i class="bi-file-person"></i> Passport </router-link></div>
           <div class="btn-group m-2" role="group" aria-label="First group"><router-link to="/" class="btn btn-danger text-center">  <i class="bi-lock-fill"></i> Security </router-link></div>
           <div class="btn-group m-2" role="group" aria-label="First group"><router-link to="/" class="btn btn-warning text-center">  <i class="bi-file-earmark"></i> Documents </router-link></div>
           <div class="btn-group m-2" role="group" aria-label="First group"><router-link to="/" class="btn btn-outline-secondary text-center">  <i class="bi-arrow-clockwise"></i> Refresh </router-link></div>
</div>

        </div>
    </div>
    </div>
</div>

    </div>
</template>