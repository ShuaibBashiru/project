export default{
    data(){
        return {
            info:[],
            progress:null,
        }
    },
    methods:{
        runtest(){
            alert("working")
        }
        
    },

}